# PhysiCell Studio

A graphical tool to create, execute, and visualize a multicellular model using PhysiCell.

https://github.com/PhysiCell-Tools/Studio-Guide/blob/main/README.md
